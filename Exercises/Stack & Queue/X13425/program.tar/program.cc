#include "CuaIOParInt.hh"

typedef queue <ParInt> Cola;

void distrib (Cola& q0, Cola& q1, Cola& q2) {
    int sumq1 = 0;
    int sumq2 = 0;
    ParInt par = q0.front();
    q1.push(par);
    sumq1 += par.segon();
    q0.pop();
    par = q0.front();
    q2.push(par);
    sumq2 += par.segon();
    q0.pop();
    while (not q0.empty()) {
        par = q0.front();
        if (sumq1 > sumq2) {
            q2.push(par);
            sumq2 += par.segon();
        }
        else {
            q1.push(par);
            sumq1 += par.segon();
        }
        q0.pop();      
    }

}

int main() {
    Cola q1;
    llegirCuaParInt(q1);
    if (not q1.empty()) {
        Cola q2;
        Cola q3;
        distrib(q1,q2,q3);
        escriureCuaParInt(q2);
        cout << endl;
        escriureCuaParInt(q3);
    }
    else cout << endl;
}
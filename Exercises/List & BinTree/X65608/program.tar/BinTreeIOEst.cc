#include "BinTreeIOEst.hh"

void read_bintree_est(BinTree<Estudiant>& a) {
    BinTree<Estudiant> l,r;
    int x;
    double y;
    cin >> x >> y;
    if(x != 0 and y != 0) {
        Estudiant Gavi (x);
        if (y >= 0 and y <= 10) Gavi.afegir_nota(y);
        read_bintree_est(l);
        read_bintree_est(r);
        a = BinTree<Estudiant>(Gavi, l, r);
    }
    else a = BinTree<Estudiant>();
}

void write_bintree_est(const BinTree<Estudiant>& a) {
    if (not a.empty()) {
        Estudiant Pedri = a.value();
        write_bintree_est(a.left());
        Pedri.escriure();
        write_bintree_est(a.right());
    }
}
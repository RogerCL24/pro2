#include "LlistaIOParInt.hh"

void LlegirLlistaParInt(list<ParInt>& l) {
    list<ParInt>::iterator it = l.end();
    ParInt p; 
    while (p.llegir()) l.insert(it, p); 
}

void EscriureLlistaParInt(const list<ParInt>& l) {
    if (not l.empty()) {
        list<ParInt>::const_iterator it;
        cout << "First" << endl;
        for (it = l.begin(); it != l.end(); ++it) {
            ParInt p = *it;
            p.escriure();
        }
        cout << "Last" << endl;
    }
    cout << endl;

}
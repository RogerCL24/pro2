#include "LlistaIOParInt.hh"

void calculate (const list<ParInt> l, int& counter, int& sum_mate, const int& x) {
    list<ParInt>::const_iterator it = l.begin();
    while (it != l.end()) {
        ParInt p = *it;
        if (p.primer() == x) {
            ++counter;
            sum_mate += p.segon();
        }
        ++it;
    }
}

int main() {
    list<ParInt> l;
    LlegirLlistaParInt(l);
    int x; 
    cin >> x;
    int counter = 0;
    int sum_mate = 0;
    calculate(l, counter, sum_mate, x);
    cout << x << " " << counter << " " << sum_mate << endl;
}
#include "BinTreeIOParInt.hh"


void read_bintree_parint(BinTree<ParInt>& a) {
    ParInt p;
    BinTree<ParInt> l, r;
    if (p.llegir()) {
        read_bintree_parint(l);
        read_bintree_parint(r);
        a = BinTree<ParInt>(p, l, r);
    }
    else a = BinTree<ParInt>();
}

void write_bintree_parint(const BinTree<ParInt>& a) {
    if (not a.empty()) {
        ParInt p = a.value();
        write_bintree_parint(a.left());
        p.escriure();
        write_bintree_parint(a.right());
    }
}
#include "LlistaIOEstudiant.hh"

void count(const list<Estudiant>& l, int dni, int& counter) {
    list<Estudiant>::const_iterator it;
    for (it = l.begin(); it != l.end(); ++it) {
        if ((*it).consultar_DNI() == dni) ++counter;
    }
}

int main() {
    list<Estudiant> l;
    LlegirLlistaEstudiant(l);
    int x;
    cin >> x;
    int counter = 0;
    count(l,x,counter);
    cout << x << " " << counter << endl;
}
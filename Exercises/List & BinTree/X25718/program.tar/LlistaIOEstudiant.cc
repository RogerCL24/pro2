#include "LlistaIOEstudiant.hh"

void LlegirLlistaEstudiant(list<Estudiant>& l) {
    list<Estudiant>::iterator it = l.end();
    int x;
    double note;
    while (cin >> x and cin >> note and x != 0) {
        Estudiant Jaume(x);
        if (note >= 0 and note <= 10) Jaume.afegir_nota(note);
        l.insert(it, Jaume);
    } 

}

void EscriureLlistaEstudiant(list<Estudiant>& l) {
    if (not l.empty()) {
        list<Estudiant>::iterator it;
        for (it = l.begin(); it != l.end(); ++it) {
            Estudiant Hamilton = *it;
            Hamilton.escriure();
        }
    }
}